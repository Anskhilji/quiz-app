-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 27, 2021 at 02:45 AM
-- Server version: 5.6.49-cll-lve
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ans_quiz`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'admin@gmail.com', '2021-02-23 14:03:08', '$2y$10$kx5cUeGcSWJN5IVWoHUwYOWEdd1SIVcOLMh2PHYjFcuRqCczxX0tK', '2Nlt8tZwG5oBQdxG8M8lccS1SIEFx27RsgluqXysCk2mU3EtEyy9KeQ4q41B', '2021-02-23 14:03:08', '2021-02-23 14:03:08');

-- --------------------------------------------------------

--
-- Table structure for table `attempts`
--

CREATE TABLE `attempts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `teacher_id` bigint(20) UNSIGNED DEFAULT NULL,
  `subject_id` bigint(20) UNSIGNED DEFAULT NULL,
  `question_id` int(255) DEFAULT NULL,
  `text_ans` text COLLATE utf8mb4_unicode_ci,
  `result_announce` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `total_marks` int(11) DEFAULT NULL,
  `obtained_marks` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `attempts`
--

INSERT INTO `attempts` (`id`, `user_id`, `teacher_id`, `subject_id`, `question_id`, `text_ans`, `result_announce`, `status`, `total_marks`, `obtained_marks`, `created_at`, `updated_at`) VALUES
(24, 100001, 111016, 15, 61, '[{\"id\":\"20\",\"type\":\"m\",\"select\":\"Quaid-e-Azam\"},{\"id\":\"21\",\"type\":\"m\",\"select\":\"9 years\"},{\"id\":\"28\",\"type\":\"t\",\"ans\":\"tst\"}]', '2021-03-31 12:08', 1, 7, 6, '2021-03-31 19:06:22', '2021-03-31 19:06:59'),
(25, 100010, 111021, 17, 63, '[{\"id\":\"33\",\"type\":\"m\",\"select\":\"Yes\"},{\"id\":\"31\",\"type\":\"t\",\"ans\":\"Your Registration Request is Approved\"},{\"id\":\"32\",\"type\":\"t\",\"ans\":\"Your Registration Request is Approved\"}]', '2021-05-17 16:55', 1, 11, 9, '2021-05-17 23:50:17', '2021-05-17 23:52:57');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `forms`
--

CREATE TABLE `forms` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `forms`
--

INSERT INTO `forms` (`id`, `name`, `email`, `password`) VALUES
(1, 'jixecomybe@mailinator.com', 'bominityka@mailinator.com', 'Pa$$w0rd!'),
(2, 'fugo@mailinator.com', 'nowaqutore@mailinator.com', 'Pa$$w0rd!'),
(3, 'disazegaro@mailinator.com', 'jikehaduqy@mailinator.com', 'Pa$$w0rd!'),
(4, 'Xerxes Branch', 'gecodagex@mailinator.com', 'Pa$$w0rd!'),
(5, 'Slade Rodriguez', 'gywugij@mailinator.com', 'Pa$$w0rd!'),
(6, 'Maris Shepherd', 'cofybebyvo@mailinator.com', 'Pa$$w0rd!'),
(7, 'Sybill Andrews', 'bumyqi@mailinator.com', 'Pa$$w0rd!'),
(8, 'Chadwick Foreman', 'qaqino@mailinator.com', 'Pa$$w0rd!'),
(9, 'Isabella Ray', 'peso@mailinator.com', 'Pa$$w0rd!'),
(10, 'Audra Fuentes', 'wafuzut@mailinator.com', 'Pa$$w0rd!'),
(11, 'Giselle Le', 'qozuve@mailinator.com', 'Pa$$w0rd!'),
(12, 'Hoyt Rocha', 'pybepagaji@mailinator.com', 'Pa$$w0rd!'),
(13, 'Aiko Coleman', 'buby@mailinator.com', 'Pa$$w0rd!'),
(14, 'Kirby Knapp', 'byluvur@mailinator.com', 'Pa$$w0rd!'),
(15, 'Sybill Levine', 'jibe@mailinator.com', 'Pa$$w0rd!'),
(16, 'Stacy Russell', 'leborejyh@mailinator.com', 'Pa$$w0rd!'),
(17, 'Zenaida Raymond', 'panasov@mailinator.com', 'Pa$$w0rd!'),
(18, 'Marsden Mays', 'xyheku@mailinator.com', 'Pa$$w0rd!'),
(19, 'Jessamine Stevenson', 'rigyxode@mailinator.com', 'Pa$$w0rd!'),
(20, 'Jerome Wise', 'rulizaf@mailinator.com', 'Pa$$w0rd!'),
(21, 'Amal Wood', 'poleq@mailinator.com', 'Pa$$w0rd!'),
(22, 'Candice King', 'kisar@mailinator.com', 'Pa$$w0rd!'),
(23, 'Kim Farmer', 'gupomyja@mailinator.com', 'Pa$$w0rd!'),
(24, 'Roanna Davenport', 'lyjup@mailinator.com', 'Pa$$w0rd!'),
(25, 'Jada Ingram', 'symu@mailinator.com', 'Pa$$w0rd!'),
(26, 'Alden Jackson', 'vaqep@mailinator.com', 'Pa$$w0rd!'),
(27, 'Jacob Conway', 'hogevinize@mailinator.com', 'Pa$$w0rd!'),
(28, 'Mara Rivers', 'wijilufyh@mailinator.com', 'Pa$$w0rd!'),
(29, 'Chelsea Harper', 'cygupyq@mailinator.com', 'Pa$$w0rd!'),
(30, 'Quynn Little', 'fomypy@mailinator.com', 'Pa$$w0rd!'),
(31, 'May Osborne', 'xygihika@mailinator.com', 'Pa$$w0rd!'),
(32, 'May Osborne', 'xygihika@mailinator.com', 'Pa$$w0rd!'),
(33, 'Astra Pacheco', 'lyniko@mailinator.com', 'Pa$$w0rd!'),
(34, 'Tamara Chambers', 'nibupob@mailinator.com', 'Pa$$w0rd!'),
(35, 'Gemma Whitehead', 'migo@mailinator.com', 'Pa$$w0rd!'),
(36, 'Aquila Clements', 'nigyh@mailinator.com', 'Pa$$w0rd!'),
(37, 'Flavia Morse', 'bywal@mailinator.com', 'Pa$$w0rd!'),
(38, 'Noelle Knapp', 'zynurudyje@mailinator.com', 'Pa$$w0rd!'),
(39, 'Jenna Nguyen', 'zigokylum@mailinator.com', 'Pa$$w0rd!'),
(40, 'Raphael Pace', 'cuveduhir@mailinator.com', 'Pa$$w0rd!'),
(41, 'Ava Burton', 'hofuw@mailinator.com', 'Pa$$w0rd!'),
(42, 'Keegan Reid', 'hexawuh@mailinator.com', 'Pa$$w0rd!'),
(43, 'Vaughan Cleveland', 'vyfahotu@mailinator.com', 'Pa$$w0rd!'),
(44, 'Jonah Ballard', 'decetibi@mailinator.com', 'Pa$$w0rd!');

-- --------------------------------------------------------

--
-- Table structure for table `jsons`
--

CREATE TABLE `jsons` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `json_name` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `papers`
--

CREATE TABLE `papers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `teacher_id` bigint(20) UNSIGNED DEFAULT NULL,
  `subject_id` bigint(20) UNSIGNED DEFAULT NULL,
  `question` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `option_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `option_2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `option_3` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `option_4` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `correct` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `question_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text` text COLLATE utf8mb4_unicode_ci,
  `text_ans` text COLLATE utf8mb4_unicode_ci,
  `text_marks` int(11) DEFAULT '0',
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `papers`
--

INSERT INTO `papers` (`id`, `teacher_id`, `subject_id`, `question`, `option_1`, `option_2`, `option_3`, `option_4`, `correct`, `question_type`, `text`, `text_ans`, `text_marks`, `status`, `created_at`, `updated_at`) VALUES
(20, 111016, 15, 'Who was the first President of the Constituent Assembly of Pakistan?', 'Liaquat Ali Khan', 'Quaid-e-Azam', 'Moulvi Tameez-ud-Din', 'Sardar Abdur Rab Nishtar', 'Quaid-e-Azam', 'm', NULL, NULL, 0, NULL, '2021-03-30 01:49:17', '2021-03-30 01:49:17'),
(21, 111016, 15, 'After how many years Pakistan got its first constitution?', '5 years', '7 years', '9 years', '11 years', '9 years', 'm', NULL, NULL, 0, NULL, '2021-03-30 01:50:13', '2021-03-30 01:50:13'),
(22, 111016, 15, 'When the Constituent Assembly passed the Objective Resolution?', '14th February 1949', '12th March 1949', '9th June 1949', '15th August 1949', '12th March 1949', 'm', NULL, NULL, 0, NULL, '2021-03-30 01:51:09', '2021-03-30 01:51:09'),
(23, 111016, 15, 'When Mohammad Ali Bogra presented Bogra Formula in the assembly?', 'January 1953', 'April 1953', 'September 1953', 'October 1953', 'October 1953', 'm', NULL, NULL, 0, NULL, '2021-03-30 01:52:28', '2021-03-30 01:52:28'),
(24, 111016, 15, 'Who was Mohammad Ali Bogra?', 'Prime Minister', 'Foreign Minister', 'Law Minister', 'Parliament Minister', 'Prime Minister', 'm', NULL, NULL, 0, NULL, '2021-03-30 01:54:07', '2021-03-30 01:54:07'),
(25, 111016, 15, 'What is the other name of Mohammad Ali Bogra Formula?', 'New Law of Pakistan', 'Pakistan Report', 'Third Report', 'Constitutional Formula', 'Constitutional Formula', 'm', NULL, NULL, 0, NULL, '2021-03-30 01:55:03', '2021-03-30 01:55:03'),
(26, 111016, 15, 'When first constitution of Pakistan was enforced?', '8th June 1956', '23rd March 1956', '14th August 1956', '25th December 1956', '23rd March 1956', 'm', NULL, NULL, 0, NULL, '2021-03-30 01:55:53', '2021-03-30 01:55:53'),
(27, 111016, 15, 'What official name was given to Pakistan in 1956 constitution?', 'United States of Pakistan', 'Republic of Pakistan', 'Islamic Pakistan', 'Islamic Republic of Pakistan', 'Islamic Republic of Pakistan', 'm', NULL, NULL, 0, NULL, '2021-03-30 01:57:04', '2021-03-30 01:57:04'),
(28, 111016, 15, 'write a note on the creation of bangladesh', NULL, NULL, NULL, NULL, NULL, 't', 'The borders of modern Bangladesh were established with the separation of Bengal and India in August 1947, when the region became East Pakistan as a part of the newly formed State of Pakistan following the end of British rule in the region.[10] Proclamation of Bangladeshi Independence in March 1971 led to the nine-month long Bangladesh Liberation War, that culminated with East Pakistan emerging as the People\'s Republic of Bangladesh', NULL, 5, NULL, '2021-03-30 01:57:53', '2021-03-30 01:57:53'),
(29, 111016, 14, 'A group of giraffe is known as:__________?', 'Tower', 'Herd', 'Flock', 'None of these', 'Tower', 'm', NULL, NULL, 0, NULL, '2021-03-31 16:46:50', '2021-03-31 16:46:50'),
(30, 111016, 14, 'write an essay on My Father', NULL, NULL, NULL, NULL, NULL, 't', 'Nulla quis lorem ut libero malesuada feugiat. Donec sollicitudin molestie malesuada. Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a. Vivamus suscipit tortor eget felis porttitor volutpat.', NULL, 5, NULL, '2021-03-31 16:48:05', '2021-03-31 16:48:05'),
(31, 111021, 17, 'who are you?', NULL, NULL, NULL, NULL, NULL, 't', NULL, NULL, 5, NULL, '2021-05-17 23:35:36', '2021-05-17 23:35:36'),
(32, 111021, 17, 'What is PF?', NULL, NULL, NULL, NULL, NULL, 't', NULL, NULL, 5, NULL, '2021-05-17 23:36:06', '2021-05-17 23:36:06'),
(33, 111021, 17, 'Human?', 'Yes', 'No', 'Both', 'No One', 'Yes', 'm', NULL, NULL, 0, NULL, '2021-05-17 23:38:54', '2021-05-17 23:38:54');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `teacher_id` varchar(255) NOT NULL,
  `subject_id` varchar(255) NOT NULL,
  `question_id` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `start_time` text,
  `end_time` text,
  `total_markes` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `teacher_id`, `subject_id`, `question_id`, `date`, `start_time`, `end_time`, `total_markes`) VALUES
(59, '111016', '14', '29,30', '2021-03-31', '12:00', '13:00', NULL),
(60, '111016', '14', '29,30', '2021-03-31', '14:00', '14:30', NULL),
(61, '111016', '15', '20,21,28', '2021-03-31', '11:50', '11:55', NULL),
(62, '111016', '15', '20,21,28', '2021-03-31', '12:00', '12:47', NULL),
(63, '111021', '17', '33,31,32', '2021-05-17', '16:45', '17:40', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `requests`
--

CREATE TABLE `requests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `subject_id` bigint(20) UNSIGNED NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `requests`
--

INSERT INTO `requests` (`id`, `user_id`, `subject_id`, `status`, `created_at`, `updated_at`) VALUES
(18, 100001, 12, '1', '2021-03-29 08:43:41', '2021-03-29 04:51:49'),
(20, 100001, 13, '1', '2021-03-29 09:41:11', '2021-03-29 04:51:51'),
(21, 100001, 15, '1', '2021-03-30 02:09:53', '2021-03-30 02:11:25'),
(22, 100001, 14, '1', '2021-03-31 16:49:06', '2021-03-31 16:49:15'),
(23, 100007, 15, '0', '2021-05-10 20:50:46', '2021-05-10 20:50:46'),
(24, 100008, 16, '0', '2021-05-12 02:54:26', '2021-05-12 02:54:26'),
(25, 100010, 17, '1', '2021-05-17 23:48:57', '2021-05-17 23:49:14');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `teacher_id` bigint(20) UNSIGNED NOT NULL,
  `subject_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `teacher_id`, `subject_name`, `subject_code`, `created_at`, `updated_at`) VALUES
(14, 111016, 'English', 'eng101', '2021-03-30 01:22:32', '2021-03-30 01:22:32'),
(15, 111016, 'Pak Study', 'pak102', '2021-03-30 01:30:53', '2021-03-30 01:30:53'),
(16, 111017, 'English Functional', 'eng101', '2021-05-12 02:54:08', '2021-05-12 02:54:08'),
(17, 111021, 'PF', 'pf101', '2021-05-17 23:34:01', '2021-05-17 23:34:01');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `prefix` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'tc',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`id`, `prefix`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(111016, 'tc', 'Anskhan', 'anskhilji900@gmail.com', NULL, '$2y$10$L0iUUcvziDedI7X5QayVZeJ93f12DzvWkrH.v/vLvq2wO6VT2hnom', '9tU901vB6SGCmq9XS59vtZmL7Z1JlYJE0DydPwuIGGJE9SqncN83a1IZkJpY', '2021-03-26 12:24:36', '2021-03-26 14:07:01'),
(111017, 'tc', 'hassan', 'hassan@gmail.com', NULL, '$2y$10$uvrFKGd2EKsrvDVwoGRome1vwEsmmwGkouDRSiUisu6aS9NCKFVD2', NULL, '2021-05-12 02:53:32', '2021-05-25 01:13:02'),
(111018, 'tc', 'ubaid', 'obaidurrehman841@gmail.com', NULL, '$2y$10$9q3n6njEO73yLM84LA2jCOW5iHgurfW3cKl8dVc.HudruzRLEqIMy', NULL, '2021-05-16 23:08:13', '2021-05-16 23:08:13'),
(111021, 'tc', 'saqib', 'muhammadsaqib.ms228@gmail.com', NULL, '$2y$10$SZX3zClDO4yDpmNe5VwuoewGX3MOW.FEOJj4l3tpLexKHkwD0asmK', NULL, '2021-05-17 23:30:16', '2021-05-17 23:30:16');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prefix` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'stu',
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `prefix`, `email`, `status`, `token`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(100001, 'Anskhan', 'stu', 'anskhilji900@gmail.com', '1', '9ac991938fcb1383684d6f190138adb0d318fc0c2205d425586cafd9a826921c', NULL, '$2y$10$wVQwMWJTGrw/mQZAswIRk.WBCcM/HL4XJvud6B0V1rFn4gxJ5tAkm', 'xgME88YZUGDSVgtGT7qdqNBqK0ocuboTimxVL6XZFXCNoBVvAPWV4aU9pTep', '2021-03-26 09:06:59', '2021-03-31 23:09:02'),
(100002, 'Asfand', 'stu', 'kasfand727@gmail.com', '1', NULL, NULL, '$2y$10$6IjHQIoRFjJk/sCpjG5jv.Bsjzvqw1CP0eHhwJ0d5vfVuLsfb6BMS', NULL, '2021-03-26 10:14:49', '2021-03-26 10:15:03'),
(100003, 'test', 'stu', 'test@gmail.com', NULL, NULL, NULL, '$2y$10$4L7mXZaILMbuobO5iN/K3e2gHHCO5y5E4/rvtu0pc8dLjxNr4FzUq', NULL, '2021-04-29 23:34:12', '2021-04-29 23:34:12'),
(100004, 'ubaid rehman', 'stu', 'shoibmuhammad295@gmail.com', '1', NULL, NULL, '$2y$10$KNGp7mSdNcTOtk2JFDs3ne4moc4u4/j/FyOOKH/peLqyV/eqaVrzG', NULL, '2021-05-09 20:52:20', '2021-05-09 20:56:50'),
(100006, 'hassan', 'stu', 'hbhatti063@gmail.com', '1', NULL, NULL, '$2y$10$eGomXPK9NicWYzu6ZO39rOW5.bbbXSwibUvsszQGUDmQK47iCfBWe', NULL, '2021-05-10 01:05:34', '2021-05-10 20:45:36'),
(100007, 'Ubaid ur rehman', 'stu', 'obaidurrehman841@gmail.com', '1', NULL, NULL, '$2y$10$3gQOmU/LlTDOpoMMGVkwD.z01qvBgabHthneNBd7RrKv7cXZoVKRm', NULL, '2021-05-10 20:47:59', '2021-05-10 20:48:15'),
(100008, 'junaid jamshaid', 'stu', 'junaidalams0001@gmail.com', '1', NULL, NULL, '$2y$10$xCbm9fd.QkiMB1wMsU6vIeFM8jkD4LmtOwKNY/Wq6STcAwJIhFmUm', NULL, '2021-05-12 02:51:01', '2021-05-12 02:51:18'),
(100009, 'Mohsin', 'stu', 'mohsinakhtar209@gmail.com', '1', NULL, NULL, '$2y$10$2/.uCuEqJJvLxOqpk3lBKuDIAZrbm6Vg6mALyZdawNKfITck958/6', NULL, '2021-05-17 23:16:28', '2021-05-25 01:10:59'),
(100010, 'saqib', 'stu', 'muhammadsaqib.ms228@gmail.com', '1', NULL, NULL, '$2y$10$Nt9d/jLVBSZZ7pc.F4NWWuyne855rIWczDwWdrlKtwJ/x9y8g9i02', NULL, '2021-05-17 23:46:50', '2021-05-17 23:47:06');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attempts`
--
ALTER TABLE `attempts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `forms`
--
ALTER TABLE `forms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jsons`
--
ALTER TABLE `jsons`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `papers`
--
ALTER TABLE `papers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `papers_teacher_id_foreign` (`teacher_id`),
  ADD KEY `papers_subject_id_foreign` (`subject_id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `requests`
--
ALTER TABLE `requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `attempts`
--
ALTER TABLE `attempts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `forms`
--
ALTER TABLE `forms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `jsons`
--
ALTER TABLE `jsons`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `papers`
--
ALTER TABLE `papers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT for table `requests`
--
ALTER TABLE `requests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `subjects`
--
ALTER TABLE `subjects`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111022;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100011;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
