-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 30, 2021 at 06:14 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quiz`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE IF NOT EXISTS `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'admin@gmail.com', '2021-02-23 14:03:08', '$2y$10$kx5cUeGcSWJN5IVWoHUwYOWEdd1SIVcOLMh2PHYjFcuRqCczxX0tK', 'EDhlrsyGeR5z9ooSaiXKocyaxvjkXlShiD5ae9eheg0azlcPnciKfahCBjlQ', '2021-02-23 14:03:08', '2021-02-23 14:03:08');

-- --------------------------------------------------------

--
-- Table structure for table `attempts`
--

CREATE TABLE IF NOT EXISTS `attempts` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `teacher_id` bigint(20) UNSIGNED DEFAULT NULL,
  `subject_id` bigint(20) UNSIGNED DEFAULT NULL,
  `question_id` int(255) DEFAULT NULL,
  `text_ans` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `result_announce` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `total_marks` int(11) DEFAULT NULL,
  `obtained_marks` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `attempts`
--

INSERT INTO `attempts` (`id`, `user_id`, `teacher_id`, `subject_id`, `question_id`, `text_ans`, `result_announce`, `status`, `total_marks`, `obtained_marks`, `created_at`, `updated_at`) VALUES
(17, 100001, 111016, 15, 24, '[{\"id\":\"20\",\"type\":\"m\",\"select\":\"Sardar Abdur Rab Nishtar\"},{\"id\":\"22\",\"type\":\"m\",\"select\":\"12th March 1949\"},{\"id\":\"23\",\"type\":\"m\",\"select\":\"January 1953\"},{\"id\":\"28\",\"type\":\"t\",\"ans\":\"test\"}]', NULL, 1, 13, 5, '2021-03-30 09:54:41', '2021-03-30 11:30:34'),
(18, 100001, 111016, 15, 25, '[{\"id\":\"20\",\"type\":\"m\",\"select\":\"Quaid-e-Azam\"},{\"id\":\"21\",\"type\":\"m\",\"select\":\"9 years\"},{\"id\":\"22\",\"type\":\"m\",\"select\":\"15th August 1949\"},{\"id\":\"28\",\"type\":\"t\",\"ans\":\"rddfygiuh\"}]', NULL, 1, 8, 6, '2021-03-30 10:31:07', '2021-03-30 11:39:20'),
(19, 100001, 111016, 15, 26, '[{\"id\":\"20\",\"type\":\"m\",\"select\":\"Quaid-e-Azam\"},{\"id\":\"21\",\"type\":\"m\",\"select\":\"5 years\"},{\"id\":\"22\",\"type\":\"m\",\"select\":\"15th August 1949\"},{\"id\":\"26\",\"type\":\"m\",\"select\":\"8th June 1956\"},{\"id\":\"28\",\"type\":\"t\",\"ans\":\"test\"}]', '2021-03-31 08:35', 1, 13, 5, '2021-03-30 10:42:01', '2021-03-30 13:33:50'),
(20, 100001, 111016, 15, 28, '[{\"id\":\"20\",\"type\":\"m\",\"select\":\"Quaid-e-Azam\"},{\"id\":\"22\",\"type\":\"m\",\"select\":\"14th February 1949\"},{\"id\":\"28\",\"type\":\"t\",\"ans\":\"test\"}]', '2021-03-30 19:17', 1, 7, 4, '2021-03-30 10:50:01', '2021-03-30 14:16:14'),
(21, 100001, 111016, 15, 30, '[{\"id\":\"20\",\"type\":\"m\",\"select\":\"Quaid-e-Azam\"},{\"id\":\"28\",\"type\":\"t\",\"ans\":\"test\"}]', NULL, 0, NULL, NULL, '2021-03-30 11:12:03', '2021-03-30 11:12:03'),
(22, 100001, 111016, 15, 33, '[{\"id\":\"20\",\"type\":\"m\",\"select\":null},{\"id\":\"28\",\"type\":\"t\",\"ans\":null}]', NULL, 0, NULL, NULL, '2021-03-30 11:21:01', '2021-03-30 11:21:01');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `forms`
--

CREATE TABLE IF NOT EXISTS `forms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `forms`
--

INSERT INTO `forms` (`id`, `name`, `email`, `password`) VALUES
(1, 'jixecomybe@mailinator.com', 'bominityka@mailinator.com', 'Pa$$w0rd!'),
(2, 'fugo@mailinator.com', 'nowaqutore@mailinator.com', 'Pa$$w0rd!'),
(3, 'disazegaro@mailinator.com', 'jikehaduqy@mailinator.com', 'Pa$$w0rd!'),
(4, 'Xerxes Branch', 'gecodagex@mailinator.com', 'Pa$$w0rd!'),
(5, 'Slade Rodriguez', 'gywugij@mailinator.com', 'Pa$$w0rd!'),
(6, 'Maris Shepherd', 'cofybebyvo@mailinator.com', 'Pa$$w0rd!'),
(7, 'Sybill Andrews', 'bumyqi@mailinator.com', 'Pa$$w0rd!'),
(8, 'Chadwick Foreman', 'qaqino@mailinator.com', 'Pa$$w0rd!'),
(9, 'Isabella Ray', 'peso@mailinator.com', 'Pa$$w0rd!'),
(10, 'Audra Fuentes', 'wafuzut@mailinator.com', 'Pa$$w0rd!'),
(11, 'Giselle Le', 'qozuve@mailinator.com', 'Pa$$w0rd!'),
(12, 'Hoyt Rocha', 'pybepagaji@mailinator.com', 'Pa$$w0rd!'),
(13, 'Aiko Coleman', 'buby@mailinator.com', 'Pa$$w0rd!'),
(14, 'Kirby Knapp', 'byluvur@mailinator.com', 'Pa$$w0rd!'),
(15, 'Sybill Levine', 'jibe@mailinator.com', 'Pa$$w0rd!'),
(16, 'Stacy Russell', 'leborejyh@mailinator.com', 'Pa$$w0rd!'),
(17, 'Zenaida Raymond', 'panasov@mailinator.com', 'Pa$$w0rd!'),
(18, 'Marsden Mays', 'xyheku@mailinator.com', 'Pa$$w0rd!'),
(19, 'Jessamine Stevenson', 'rigyxode@mailinator.com', 'Pa$$w0rd!'),
(20, 'Jerome Wise', 'rulizaf@mailinator.com', 'Pa$$w0rd!'),
(21, 'Amal Wood', 'poleq@mailinator.com', 'Pa$$w0rd!'),
(22, 'Candice King', 'kisar@mailinator.com', 'Pa$$w0rd!'),
(23, 'Kim Farmer', 'gupomyja@mailinator.com', 'Pa$$w0rd!'),
(24, 'Roanna Davenport', 'lyjup@mailinator.com', 'Pa$$w0rd!'),
(25, 'Jada Ingram', 'symu@mailinator.com', 'Pa$$w0rd!'),
(26, 'Alden Jackson', 'vaqep@mailinator.com', 'Pa$$w0rd!'),
(27, 'Jacob Conway', 'hogevinize@mailinator.com', 'Pa$$w0rd!'),
(28, 'Mara Rivers', 'wijilufyh@mailinator.com', 'Pa$$w0rd!'),
(29, 'Chelsea Harper', 'cygupyq@mailinator.com', 'Pa$$w0rd!'),
(30, 'Quynn Little', 'fomypy@mailinator.com', 'Pa$$w0rd!'),
(31, 'May Osborne', 'xygihika@mailinator.com', 'Pa$$w0rd!'),
(32, 'May Osborne', 'xygihika@mailinator.com', 'Pa$$w0rd!'),
(33, 'Astra Pacheco', 'lyniko@mailinator.com', 'Pa$$w0rd!'),
(34, 'Tamara Chambers', 'nibupob@mailinator.com', 'Pa$$w0rd!'),
(35, 'Gemma Whitehead', 'migo@mailinator.com', 'Pa$$w0rd!'),
(36, 'Aquila Clements', 'nigyh@mailinator.com', 'Pa$$w0rd!'),
(37, 'Flavia Morse', 'bywal@mailinator.com', 'Pa$$w0rd!'),
(38, 'Noelle Knapp', 'zynurudyje@mailinator.com', 'Pa$$w0rd!'),
(39, 'Jenna Nguyen', 'zigokylum@mailinator.com', 'Pa$$w0rd!'),
(40, 'Raphael Pace', 'cuveduhir@mailinator.com', 'Pa$$w0rd!'),
(41, 'Ava Burton', 'hofuw@mailinator.com', 'Pa$$w0rd!'),
(42, 'Keegan Reid', 'hexawuh@mailinator.com', 'Pa$$w0rd!'),
(43, 'Vaughan Cleveland', 'vyfahotu@mailinator.com', 'Pa$$w0rd!'),
(44, 'Jonah Ballard', 'decetibi@mailinator.com', 'Pa$$w0rd!');

-- --------------------------------------------------------

--
-- Table structure for table `jsons`
--

CREATE TABLE IF NOT EXISTS `jsons` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `json_name` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `papers`
--

CREATE TABLE IF NOT EXISTS `papers` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `teacher_id` bigint(20) UNSIGNED DEFAULT NULL,
  `subject_id` bigint(20) UNSIGNED DEFAULT NULL,
  `question` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `option_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `option_2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `option_3` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `option_4` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `correct` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `question_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text_ans` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text_marks` int(11) DEFAULT 0,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `papers_teacher_id_foreign` (`teacher_id`),
  KEY `papers_subject_id_foreign` (`subject_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `papers`
--

INSERT INTO `papers` (`id`, `teacher_id`, `subject_id`, `question`, `option_1`, `option_2`, `option_3`, `option_4`, `correct`, `question_type`, `text`, `text_ans`, `text_marks`, `status`, `created_at`, `updated_at`) VALUES
(20, 111016, 15, 'Who was the first President of the Constituent Assembly of Pakistan?', 'Liaquat Ali Khan', 'Quaid-e-Azam', 'Moulvi Tameez-ud-Din', 'Sardar Abdur Rab Nishtar', 'Quaid-e-Azam', 'm', NULL, NULL, 0, NULL, '2021-03-30 01:49:17', '2021-03-30 01:49:17'),
(21, 111016, 15, 'After how many years Pakistan got its first constitution?', '5 years', '7 years', '9 years', '11 years', '9 years', 'm', NULL, NULL, 0, NULL, '2021-03-30 01:50:13', '2021-03-30 01:50:13'),
(22, 111016, 15, 'When the Constituent Assembly passed the Objective Resolution?', '14th February 1949', '12th March 1949', '9th June 1949', '15th August 1949', '12th March 1949', 'm', NULL, NULL, 0, NULL, '2021-03-30 01:51:09', '2021-03-30 01:51:09'),
(23, 111016, 15, 'When Mohammad Ali Bogra presented Bogra Formula in the assembly?', 'January 1953', 'April 1953', 'September 1953', 'October 1953', 'October 1953', 'm', NULL, NULL, 0, NULL, '2021-03-30 01:52:28', '2021-03-30 01:52:28'),
(24, 111016, 15, 'Who was Mohammad Ali Bogra?', 'Prime Minister', 'Foreign Minister', 'Law Minister', 'Parliament Minister', 'Prime Minister', 'm', NULL, NULL, 0, NULL, '2021-03-30 01:54:07', '2021-03-30 01:54:07'),
(25, 111016, 15, 'What is the other name of Mohammad Ali Bogra Formula?', 'New Law of Pakistan', 'Pakistan Report', 'Third Report', 'Constitutional Formula', 'Constitutional Formula', 'm', NULL, NULL, 0, NULL, '2021-03-30 01:55:03', '2021-03-30 01:55:03'),
(26, 111016, 15, 'When first constitution of Pakistan was enforced?', '8th June 1956', '23rd March 1956', '14th August 1956', '25th December 1956', '23rd March 1956', 'm', NULL, NULL, 0, NULL, '2021-03-30 01:55:53', '2021-03-30 01:55:53'),
(27, 111016, 15, 'What official name was given to Pakistan in 1956 constitution?', 'United States of Pakistan', 'Republic of Pakistan', 'Islamic Pakistan', 'Islamic Republic of Pakistan', 'Islamic Republic of Pakistan', 'm', NULL, NULL, 0, NULL, '2021-03-30 01:57:04', '2021-03-30 01:57:04'),
(28, 111016, 15, 'write a note on the creation of bangladesh', NULL, NULL, NULL, NULL, NULL, 't', 'The borders of modern Bangladesh were established with the separation of Bengal and India in August 1947, when the region became East Pakistan as a part of the newly formed State of Pakistan following the end of British rule in the region.[10] Proclamation of Bangladeshi Independence in March 1971 led to the nine-month long Bangladesh Liberation War, that culminated with East Pakistan emerging as the People\'s Republic of Bangladesh', NULL, 5, NULL, '2021-03-30 01:57:53', '2021-03-30 01:57:53');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE IF NOT EXISTS `questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_id` varchar(255) NOT NULL,
  `subject_id` varchar(255) NOT NULL,
  `question_id` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `start_time` text DEFAULT NULL,
  `end_time` text DEFAULT NULL,
  `total_markes` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `teacher_id`, `subject_id`, `question_id`, `date`, `start_time`, `end_time`, `total_markes`) VALUES
(23, '111016', '15', '20,21,22,23,24,25,26,27,28', '2021-03-31', '14:50', '14:40', NULL),
(24, '111016', '15', '20,22,23,28', '2021-03-30', '14:50', '15:10', NULL),
(25, '111016', '15', '20,21,22,28', '2021-03-30', '15:05', '16:00', NULL),
(26, '111016', '15', '20,21,22,26,28', '2021-03-30', '15:40', '15:42', NULL),
(27, '111016', '15', '20,28', '2021-03-30', '15:44', '15:45', NULL),
(28, '111016', '15', '20,22,28', '2021-03-30', '15:48', '15:50', NULL),
(29, '111016', '15', '20,28', '2021-03-30', '15:57', '15:58', NULL),
(30, '111016', '15', '20,28', '2021-03-30', '16:00', '17:00', NULL),
(31, '111016', '15', '20,28', '2021-03-30', '17:11', '18:11', NULL),
(32, '111016', '15', '20,28', '2021-03-30', '16:18', '16:19', NULL),
(33, '111016', '15', '20,28', '2021-03-30', '16:20', '16:21', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `requests`
--

CREATE TABLE IF NOT EXISTS `requests` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `subject_id` bigint(20) UNSIGNED NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `requests`
--

INSERT INTO `requests` (`id`, `user_id`, `subject_id`, `status`, `created_at`, `updated_at`) VALUES
(18, 100001, 12, '1', '2021-03-29 08:43:41', '2021-03-29 04:51:49'),
(20, 100001, 13, '1', '2021-03-29 09:41:11', '2021-03-29 04:51:51'),
(21, 100001, 15, '1', '2021-03-30 02:09:53', '2021-03-30 02:11:25');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE IF NOT EXISTS `subjects` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `teacher_id` bigint(20) UNSIGNED NOT NULL,
  `subject_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`id`, `teacher_id`, `subject_name`, `subject_code`, `created_at`, `updated_at`) VALUES
(14, 111016, 'English', 'eng101', '2021-03-30 01:22:32', '2021-03-30 01:22:32'),
(15, 111016, 'Pak Study', 'pak102', '2021-03-30 01:30:53', '2021-03-30 01:30:53');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE IF NOT EXISTS `teachers` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `prefix` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'tc',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=111017 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`id`, `prefix`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(111016, 'tc', 'Anskhan', 'anskhilji900@gmail.com', NULL, '$2y$10$L0iUUcvziDedI7X5QayVZeJ93f12DzvWkrH.v/vLvq2wO6VT2hnom', '0tN4yyh02MInzCIVVSc74VLlz9PfhSr9i86bRBwI2U8lSdyOqQjvf8LObUDF', '2021-03-26 12:24:36', '2021-03-26 14:07:01');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prefix` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'stu',
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=100003 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `prefix`, `email`, `status`, `token`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(100001, 'Anskhan', 'stu', 'anskhilji900@gmail.com', '1', NULL, NULL, '$2y$10$wVQwMWJTGrw/mQZAswIRk.WBCcM/HL4XJvud6B0V1rFn4gxJ5tAkm', 'vJ6qvcjdBTx22tu2dqZXoi7YGnoFem1F5rwEdKcJTf2jGR8LD1lFqAnh47Tj', '2021-03-26 09:06:59', '2021-03-26 10:05:34'),
(100002, 'Asfand', 'stu', 'kasfand727@gmail.com', '1', NULL, NULL, '$2y$10$6IjHQIoRFjJk/sCpjG5jv.Bsjzvqw1CP0eHhwJ0d5vfVuLsfb6BMS', NULL, '2021-03-26 10:14:49', '2021-03-26 10:15:03');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
